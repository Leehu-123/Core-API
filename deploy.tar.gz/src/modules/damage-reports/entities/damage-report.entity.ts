export class DamageReport {}
