export class GoodsReceipt {}
