export class Stocktake {}
