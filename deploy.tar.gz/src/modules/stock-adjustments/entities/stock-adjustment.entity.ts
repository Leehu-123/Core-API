export class StockAdjustment {}
