export class GoodsIssue {}
