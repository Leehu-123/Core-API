export class Location {}
